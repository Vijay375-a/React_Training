let a = "100";
let b = 100;
if (a == b) {
    console.log('equal')
} else {
    console.log('not equal')
}
//value is 100 but type is number
let x = "100";
let y = 100;
if (x === y) {
    console.log('equal')
} else {
    console.log('not equal')
}