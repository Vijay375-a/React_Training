//numbers
let salary = 10000;
console.log(`Salary ${salary}`);
let totalSalary = salary * 100
console.log(`Total salary ${totalSalary}`);
