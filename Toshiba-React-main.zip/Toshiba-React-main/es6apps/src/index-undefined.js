//undefined; if variable declared but not initalized with any valid literals
let cost;
console.log(`cost ${cost}`);