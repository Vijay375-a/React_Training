//let is for declaring variable
//const is also keyword to declare variable

let a = 10;
a = 20;
a = 30;
console.log(a)

//read only
const b =10;
console.log(b)
b=90;