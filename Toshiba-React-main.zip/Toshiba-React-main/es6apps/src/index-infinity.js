let avg = 100/ 0;
console.log(`Avg ${avg}`);