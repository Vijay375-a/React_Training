let isActive = true;

if (isActive) {
    console.log('Active')
} else {
    console.log('inactive')
}
let firstName="subramanian"
if (firstName) {
    console.log('Name is Present')
} else {
    console.log('Name is not  Present')
}

let start=NaN;
if (start) {
    console.log('start')
} else {
    console.log('no start')
}
